//
// Point3.h
// 
// David Harrigan
//

#ifndef Point3_h
#define Point3_h

class Point3 {
public:
    float x;
    float y;
    float z;
    
    Point3();
    Point3( float x, float y, float z );
}; 

#endif
