David Harrigan
Program 5 - Final Delivery 
12/15/13

I could not figure out how to do library linking the way you showed me on Friday. 
Please use the Makefile you edited for beta. Also, if you could send
me the Makefile so that I can see what you did, that would be awesome.  

Usage:
    make run  
    make run will automatically load the songs I put in the directory

Completed Tasks for Final Delivery:
    - Changed the texture effect so that it is more clear
    - Scrolling scene's boxes are now mapped by different musical
      notes rather than just a range of frequencies
    - Added some more keyboard controls
    - Can play multiple files
    - Cleaned my code

Keyboard Controls:
    n - next song
    s - change scnene
    ESC - quit
    
    Camera:
        h - left
        l - right
        j - up
        k - down
    
    Light:
        H - left
        L - right
        J - up
        K - down

    

